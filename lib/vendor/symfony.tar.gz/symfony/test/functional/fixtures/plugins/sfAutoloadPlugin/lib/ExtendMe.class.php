<?php

class ExtendMe extends BaseExtendMe
{
}
