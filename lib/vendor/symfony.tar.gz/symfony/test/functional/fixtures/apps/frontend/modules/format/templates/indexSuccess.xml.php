<sentence>This is a XML file</sentence>
