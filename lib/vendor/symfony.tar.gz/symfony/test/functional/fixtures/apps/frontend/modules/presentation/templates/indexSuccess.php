<div id="foo"><?php echo $foo ?></div>
<div id="foo_bis"><?php echo $sf_context->getController()->getPresentationFor('presentation', 'foo') ?></div>
